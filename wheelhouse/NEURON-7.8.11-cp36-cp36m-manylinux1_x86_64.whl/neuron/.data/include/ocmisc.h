#ifndef ocmisc_h
#define ocmisc_h

extern long hoc_nstack;
extern long hoc_nframe;
extern int hoc_errno_count;
extern int hoc_pipeflag;
extern int hoc_in_yyparse;
extern int hoc_intset;

#endif
