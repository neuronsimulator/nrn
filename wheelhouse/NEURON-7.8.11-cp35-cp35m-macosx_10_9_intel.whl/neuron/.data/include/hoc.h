
#ifndef hoc_h
#define hoc_h
#include "redef.h"
#include "hocdec.h"
#endif
