import sys
import neuron.rxd
sys.modules[__name__] = sys.modules['neuron.rxd']
