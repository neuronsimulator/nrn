# Avogadro's number (approximation before 2019 redefinition)
NA = 6.02214129e23 
#NA = 6.02214076e23 

