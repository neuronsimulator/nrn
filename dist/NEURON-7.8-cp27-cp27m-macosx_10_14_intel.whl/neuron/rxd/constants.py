# Avagadro's number (approximation before 2019 redefinition)
NA = 6.02214129e23 